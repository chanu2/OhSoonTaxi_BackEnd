package Tasam.apiserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
